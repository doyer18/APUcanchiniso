-- Usar base de datos master
USE master;
GO

-- Eliminar base de datos si ya existe
IF DB_ID('ApuCanchiniso') IS NOT NULL
    DROP DATABASE APUCanchiniso;
GO

-- Crear base de datos
CREATE DATABASE APUCanchiniso;
GO

-- Usar la base de datos
USE APUCanchiniso;
GO

CREATE TABLE Proveedor (
    RUC VARCHAR(11) PRIMARY KEY,
    provNombre VARCHAR(100) NOT NULL,
    provTelefono VARCHAR(20),
    provEmail VARCHAR(100)
);

CREATE TABLE Traje (
    IdTraje VARCHAR(11) PRIMARY KEY,
    NombreTraje VARCHAR(100) NOT NULL,
    Descripcion VARCHAR(255) NOT NULL,
    Talla VARCHAR(15),
    Stock INT CHECK (Stock >= 0),
    PrecioAlquiler DECIMAL(7,2) NOT NULL CHECK (PrecioAlquiler >= 0),
    Imagen VARCHAR(255) NOT NULL, 
    RUC VARCHAR(11) NOT NULL,
    FOREIGN KEY (RUC) REFERENCES Proveedor(RUC)
);

CREATE TABLE Cliente (
    IdCliente VARCHAR(10) PRIMARY KEY,
    cliNombres VARCHAR(100) NOT NULL,
    cliApePaterno VARCHAR(30) NOT NULL,
	cliApeMaterno VARCHAR(30),
    Telefono VARCHAR(20),
    Email VARCHAR(100),
    Usuario VARCHAR(50) NOT NULL UNIQUE,
    Password VARCHAR(100) NOT NULL
);

CREATE TABLE Administrador (
    DNI VARCHAR(10) PRIMARY KEY,
    NombreAdministrador NVARCHAR(100) NOT NULL,
    Usuario NVARCHAR(50) UNIQUE NOT NULL,
    Password NVARCHAR(100) NOT NULL 
);

CREATE TABLE TipoComprobante (
    IdTipoComprobante INT PRIMARY KEY,
    NombreTipo NVARCHAR(50) NOT NULL 
);

CREATE TABLE Alquiler (
    IdAlquiler VARCHAR(11) PRIMARY KEY,
    FechaAlquiler DATE NOT NULL,
    FechaDevolucion DATE,
    IdCliente VARCHAR(10) NOT NULL,
    DNI VARCHAR(10) NOT NULL,
    IdTipoComprobante INT NOT NULL,
    FOREIGN KEY (IdCliente) REFERENCES Cliente(IdCliente),
    FOREIGN KEY (DNI) REFERENCES Administrador(DNI),
    FOREIGN KEY (IdTipoComprobante) REFERENCES TipoComprobante(IdTipoComprobante)
);

CREATE TABLE Detalle_Alquiler (
    IdAlquiler VARCHAR(11) NOT NULL,
    IdTraje VARCHAR(11) NOT NULL,
    Cantidad INT NOT NULL CHECK (Cantidad > 0),
    PRIMARY KEY (IdAlquiler, IdTraje),
    FOREIGN KEY (IdAlquiler) REFERENCES Alquiler(IdAlquiler),
    FOREIGN KEY (IdTraje) REFERENCES Traje(IdTraje)
);

CREATE TABLE MetodoPago (
    IdMetodoPago VARCHAR(4) PRIMARY KEY,
    NombreMetodo NVARCHAR(50) NOT NULL
);

CREATE TABLE Pago (
    IdPago VARCHAR(11) PRIMARY KEY,
    IdAlquiler VARCHAR(11) NOT NULL,
    Monto DECIMAL(7,2) NOT NULL CHECK (Monto >= 0),
    FechaPago DATE NOT NULL,
    IdMetodoPago VARCHAR(4) NOT NULL,
    FOREIGN KEY (IdAlquiler) REFERENCES Alquiler(IdAlquiler),
    FOREIGN KEY (IdMetodoPago) REFERENCES MetodoPago(IdMetodoPago)
);

-- Inserción de Proveedores
INSERT INTO Proveedor (RUC, provNombre, provTelefono, provEmail) VALUES
('20123456789', 'Artesanías Andinas Cusco', '084123456', 'contacto@artandinas.pe'),
('20234567890', 'Moda Inca', '084234567', 'ventas@modainca.pe'),
('20345678901', 'Trajes del Sol', '084345678', 'info@trajesdelsol.pe'),
('20456789012', 'Típico Perú', '084456789', 'contacto@tipicoperu.pe'),
('20567890123', 'Cusco Tradición', '084567890', 'ventas@cuscotradicion.pe');

-- Inserción de Trajes
INSERT INTO Traje (IdTraje, NombreTraje, Descripcion, Talla, Stock, PrecioAlquiler, Imagen, RUC) VALUES
('T001', 'Traje de Marinera Norteña', 'Vestido elegante con falda amplia y blusa bordada, típico de la costa norte del Perú.', 'S-M-L', 10, 40.00, '/img/marinera_nortena.jpg', '20123456789'),
('T002', 'Traje de Danza de Tijeras', 'Conjunto colorido con adornos metálicos y espejos, representativo de Ayacucho y Huancavelica.', 'M-L', 8, 35.00, '/img/danza_tijeras.jpg', '20234567890'),
('T003', 'Traje Shipibo-Conibo', 'Vestimenta amazónica con patrones geométricos kené, usado por la comunidad Shipibo-Conibo.', 'S-M', 7, 55.00, '/img/shipibo_conibo.jpg', '20345678901'),
('T004', 'Traje de Chola Puneña', 'Pollera de felpa, blusa de lino y sombrero honguito, típico de las mujeres de Puno.', 'M-L', 12, 45.00, '/img/chola_punena.jpg', '20456789012'),
('T005', 'Traje de Qhapaq Qolla', 'Vestimenta festiva con máscaras y bordados, usada en las danzas de Paucartambo.', 'L', 5, 35.00, '/img/qhapaq_qolla.jpg', '20567890123'),
('T006', 'Traje de Huaylarsh', 'Conjunto colorido con faldas amplias y blusas bordadas, típico de la región central del Perú.', 'S-M-L', 9, 50.00, '/img/huaylarsh.jpg', '20123456789'),
('T007', 'Traje de Saya Afroboliviana', 'Vestido vibrante con influencias africanas, usado en danzas afroandinas.', 'M-L', 6, 35.00, '/img/saya_afroboliviana.jpg', '20234567890'),
('T008', 'Traje de Carnaval Ayacuchano', 'Vestimenta colorida con bordados y sombreros adornados, representativo de Ayacucho.', 'S-M', 10, 48.00, '/img/carnaval_ayacuchano.jpg', '20345678901'),
('T009', 'Traje de Tondero Piurano', 'Conjunto ligero y elegante, usado en la danza del Tondero en Piura.', 'M-L', 7, 52.00, '/img/tondero_piurano.jpg', '20456789012'),
('T010', 'Traje de Chunchos', 'Vestimenta tradicional con plumas y bordados, típica de las festividades en Cusco.', 'S-M-L', 8, 38.00, '/img/chunchos.jpg', '20567890123'),
('T011', 'Traje de Morenada', 'Conjunto vistoso con máscaras y trajes brillantes, usado en danzas del altiplano.', 'M-L', 6, 42.00, '/img/morenada.jpg', '20123456789'),
('T012', 'Traje de Waca Waca', 'Vestimenta satírica con elementos taurinos, representativa de Puno.', 'S-M', 9, 47.00, '/img/waca_waca.jpg', '20234567890'),
('T013', 'Traje de Qhapaq Negro', 'Conjunto elegante con máscaras negras y bordados dorados, usado en Paucartambo.', 'L', 5, 55.00, '/img/qhapaq_negro.jpg', '20345678901'),
('T014', 'Traje de Contradanza', 'Vestimenta colorida con elementos europeos, típica de las festividades en Cusco.', 'M-L', 7, 40.00, '/img/contradanza.jpg', '20456789012'),
('T015', 'Traje de Maqt’a', 'Conjunto tradicional con sombrero y poncho, representativo de las comunidades andinas.', 'S-M', 10, 50.00, '/img/maqta.jpg', '20567890123'),
('T016', 'Traje de Ch’unchu', 'Vestimenta con plumas y bordados, usada en danzas de la selva cusqueña.', 'M-L', 6, 35.00, '/img/chunchu.jpg', '20123456789'),
('T017', 'Traje de Saqra', 'Conjunto demoníaco con máscaras y trajes coloridos, representativo de Paucartambo.', 'S-M-L', 8, 50.00, '/img/saqra.jpg', '20234567890'),
('T018', 'Traje de Panadero', 'Vestimenta tradicional con sombrero y delantal, usada en danzas de Paucartambo.', 'M-L', 7, 45.00, '/img/panadero.jpg', '20345678901'),
('T019', 'Traje de Qoyacha', 'Conjunto femenino con faldas amplias y blusas bordadas, típico de Cusco.', 'S-M', 9, 55.00, '/img/qoyacha.jpg', '20456789012'),
('T020', 'Traje de Ch’unchachas', 'Vestimenta femenina con plumas y colores vivos, usada en danzas de la selva.', 'M-L', 6, 55.00, '/img/chunchachas.jpg', '20567890123');

-- Inserción de Clientes
INSERT INTO Cliente (IdCliente, cliNombres, cliApePaterno, cliApeMaterno, Telefono, Email, Usuario, Password) VALUES
('76591834', 'Eulalia Anastasia', 'Lucena', 'Cordero', '946277839', 'ytena@alfaro.net', 'eulalu85', '@zz^3eNs'),
('72706019', 'Ligia Eloy', 'Ribas', 'Coll', '990032120', 'susanitadomingo@diez.com', 'ligiri43', 'hp&G7NFx'),
('78056826', 'Victor Manuel', 'Reig', 'Girón', '917734977', 'ymendez@gmail.com', 'victre80', '+9gv(VWn'),
('70088681', 'Marianela Asunción', 'Lucena', 'Company', '972523586', 'patinoadelardo@hotmail.com', 'marilu45', 'x_7(XH^i'),
('79592033', 'Marisela', 'Zamora', 'Sans', '906601131', 'hcaballero@yahoo.com', 'mariza30', 'b(8OEqM2'),
('72185903', 'Luis Fernando', 'Pérez', 'Delgado', '913582741', 'lfperez@gmail.com', 'luisfe89', 'K#4wnm!x'),
('78930156', 'Paola Andrea', 'Rojas', 'Cárdenas', '952341770', 'paolarc@hotmail.com', 'paoro88', 'Qz9*R4uD'),
('70328415', 'Julio César', 'Salinas', 'Reategui', '964532188', 'julio.salinas@correo.pe', 'julcesar76', 'Tg!2JpEv'),
('74219083', 'Rocío Milagros', 'Chávez', 'Zevallos', '978321045', 'rociomz@gmail.com', 'roccha73', 'Rm6^YjW9'),
('79018473', 'David Alonso', 'Torres', 'Huamán', '916205478', 'davtorres@outlook.com', 'davtor95', '*Jx#A9lm'),
('72103849', 'Alejandra Sofía', 'Quiroz', 'Luna', '955601234', 'alejandra.ql@gmail.com', 'alesof91', 'Zp@3FgEi'),
('76301284', 'Miguel Ángel', 'Campos', 'Puma', '923114526', 'migcampos@yahoo.com', 'migcam60', 'Lo7&dT!a'),
('74981265', 'Natalia Beatriz', 'Mendoza', 'Silva', '934211870', 'nataliasilva@hotmail.com', 'natmen82', 'Ht#8PmZu'),
('70019284', 'Carlos Eduardo', 'Montoya', 'Raymundo', '987341001', 'carlosmr@correo.com', 'carmon88', 'Xp!0wKl#'),
('76520934', 'Vanessa Liseth', 'Sánchez', 'Rodríguez', '912034587', 'vanelis@correo.pe', 'vansan96', '^Wd3RpL*'),
('72287001', 'José Alejandro', 'Gonzales', 'Quispe', '945128390', 'josealejandro@live.com', 'josgon79', 'Ae*4LvQz'),
('78103921', 'Lucía Esther', 'Zevallos', 'Coa', '964271590', 'luciazc@hotmail.com', 'lucest92', 'Fk(9Uz!v'),
('79042831', 'Andrés Felipe', 'Salazar', 'Ticona', '935027481', 'andreasticona@gmail.com', 'andsal90', 'Jg^1ErAx'),
('70948132', 'Rebeca Noemí', 'Ortega', 'Villena', '974102938', 'rebvillena@yahoo.com', 'rebort82', 'Uo#3SnWt'),
('79830274', 'Fernando Luis', 'Barrenechea', 'Paredes', '900120358', 'fernandopar@gmail.com', 'ferbar94', 'Ni6*TeO@'),
('72395801', 'Liliana Ruth', 'Cornejo', 'Poma', '987130298', 'lilcornejo@hotmail.com', 'lilcor89', 'Mq@5LeUd'),
('78120394', 'Raúl Eduardo', 'Aliaga', 'Soto', '927431580', 'raualiaga@live.com', 'raulal78', 'Yw&8GiPx'),
('73492816', 'Cynthia Roxana', 'Acosta', 'Galindo', '960321074', 'cynacosta@gmail.com', 'cynaco93', 'Vc$0BnUw'),
('79102843', 'Pedro Sebastián', 'Luna', 'Arellano', '946731205', 'pedroluna@hotmail.com', 'pedlun87', 'Gp!6YtEn'),
('75201934', 'Daniela Patricia', 'Carrillo', 'Huerta', '916470213', 'danihuerta@correo.com', 'dancar91', 'Ek#7WrLp'),
('74832091', 'Oscar Iván', 'Tito', 'Carrión', '975621047', 'oscartito@live.com', 'osctit84', 'Wr8&KmPt'),
('78391042', 'Jimena Carolina', 'Aguirre', 'Farfán', '955210398', 'jimefarfan@gmail.com', 'jimagu95', 'Lt$4RpEu'),
('72938402', 'Martín Alejandro', 'Quintana', 'Ramos', '988310456', 'martinquintana@correo.pe', 'marqui77', 'Zp(9YoVr'),
('76130294', 'Valeria Mónica', 'Chura', 'Ancco', '945731842', 'valchura@outlook.com', 'valchu98', 'Ks#1NqJv'),
('79201385', 'Hugo Benjamín', 'Arévalo', 'Mamani', '924812907', 'hugomamani@yahoo.com', 'hugare99', 'Om%7XuDd'),
('70091824', 'Marcos Daniel', 'Delgado', 'Zapata', '936571293', 'marcosdz@gmail.com', 'mardel75', 'Ye^3FqNw'),
('77609135', 'Lorena Isabel', 'Gamarra', 'Sánchez', '964810376', 'lorenag@correo.pe', 'lorgam85', 'Np$2KuMf'),
('74580912', 'Álvaro Iván', 'Paz', 'Guevara', '974103592', 'alvaropaz@correo.com', 'alvpaz91', 'Cr&0XzTu'),
('77043195', 'Beatriz Adriana', 'Cáceres', 'Yupanqui', '987312054', 'beatriyu@gmail.com', 'beacac94', 'Ls*6FmEz'),
('70495821', 'Gabriela Antonia', 'Velarde', 'Raygada', '954103859', 'gabyvel@hotmail.com', 'gabvel86', 'Tu&1BrMf'),
('78932048', 'Renato Guillermo', 'Gómez', 'Berrocal', '918204736', 'renberrocal@live.com', 'rengom93', 'Zx@4WyRt'),
('71395820', 'Fiorella María', 'Rivas', 'Pineda', '936482015', 'fiorivas@hotmail.com', 'fioriv89', 'Kv!7DmLp'),
('73210598', 'Angélica Flor', 'Villanueva', 'Loayza', '970324815', 'angelicav@correo.pe', 'angvil90', 'Fw$5NpVx'),
('75913208', 'Samuel Antonio', 'Coila', 'Zárate', '947130258', 'samcoila@gmail.com', 'samcoi91', 'Wb(6KqOp'),
('79458203', 'Rosario Judith', 'Mamani', 'Apaza', '983210459', 'rosamam@gmail.com', 'rosmam92', 'Tr^9HnUl'),
('76192834', 'Jorge Enrique', 'Acuña', 'Campos', '927314056', 'joracu@hotmail.com', 'joracu89', 'Ey&3PlMe'),
('72849107', 'Erika Vanessa', 'Condori', 'Paucar', '955730298', 'ericondori@gmail.com', 'ericon96', 'Au!7LkNv'),
('78920431', 'Luis Ángel', 'Soto', 'Barrios', '942310584', 'luissoto@live.com', 'luisot84', 'Qi$2RwEt'),
('74582013', 'Tatiana Mercedes', 'Del Águila', 'Ticse', '961203845', 'tatidaguila@correo.pe', 'tatdel91', 'Df(1XpJt'),
('73214098', 'Bruno Leonardo', 'Reyes', 'Valverde', '975620138', 'brunoreyes@live.com', 'brurey97', 'Rn#4VfUx'),
('76938120', 'Adriana Karla', 'Huamán', 'Escobar', '911034789', 'adrianahescobar@gmail.com', 'adkarl88', 'Gl^2QuNm'),
('70728190', 'Diego Esteban', 'Cáceres', 'Valer', '986470123', 'diegocaceres@correo.com', 'diecac95', 'Mk&9PuTw'),
('78132094', 'Nicole Andrea', 'Peña', 'Lozano', '917103825', 'niclozano@live.com', 'nicpen93', 'Vp@6WqNr'),
('79302184', 'Ignacio Tomás', 'Fuentes', 'Ibarra', '944813602', 'ignafuentes@gmail.com', 'ignfue94', 'Ux*3KnSe'),
('70193027', 'Patricia Carolina', 'López', 'Huayhua', '935207148', 'patriciahuayhua@hotmail.com', 'patlop87', 'Qf#2VlJp');

-- Inserción de Administrador
INSERT INTO Administrador (DNI, NombreAdministrador, Usuario, Password) VALUES
('70918234', 'Carlos Alberto Ramírez Gonzales', 'carram01', 'Adm#2024!'),
('71590348', 'María Fernanda Quispe Ticona', 'marqui02', 'M@rF#nD24'),
('72619483', 'Jorge Luis Salazar Paredes', 'jorsal03', 'J0rge*Adm'),
('73105928', 'Lucía Elena Cáceres Ramos', 'luccac04', 'Luc!@2024'),
('74592831', 'Renato Iván Flores Condori', 'renflo05', 'Ren#Flo5');

-- Inserción de TipoComprobante
INSERT INTO TipoComprobante (IdTipoComprobante, NombreTipo) VALUES
(1, 'Factura'),
(2, 'Boleta de Venta');

-- Inserción de Alquiler
INSERT INTO Alquiler (IdAlquiler, FechaAlquiler, FechaDevolucion, IdCliente, DNI, IdTipoComprobante) VALUES
('ALQ000001', '2025-05-01', '2025-05-07', '76591834', '70918234', 1),
('ALQ000002', '2025-05-02', '2025-05-09', '72706019', '71590348', 2),
('ALQ000003', '2025-05-03', '2025-05-10', '78056826', '72619483', 1),
('ALQ000004', '2025-05-04', '2025-05-11', '70088681', '73105928', 2),
('ALQ000005', '2025-05-05', '2025-05-12', '79592033', '74592831', 1),
('ALQ000006', '2025-05-06', '2025-05-13', '72185903', '70918234', 2),
('ALQ000007', '2025-05-07', '2025-05-14', '78930156', '71590348', 1),
('ALQ000008', '2025-05-08', '2025-05-15', '70328415', '72619483', 2),
('ALQ000009', '2025-05-09', '2025-05-16', '74219083', '73105928', 1),
('ALQ000010', '2025-05-10', '2025-05-17', '79018473', '74592831', 2),
('ALQ000011', '2025-05-11', '2025-05-18', '72103849', '70918234', 1),
('ALQ000012', '2025-05-12', '2025-05-19', '76301284', '71590348', 2),
('ALQ000013', '2025-05-13', '2025-05-20', '74981265', '72619483', 1),
('ALQ000014', '2025-05-14', '2025-05-21', '70019284', '73105928', 2),
('ALQ000015', '2025-05-15', '2025-05-22', '76520934', '74592831', 1),
('ALQ000016', '2025-05-16', '2025-05-23', '72287001', '70918234', 2),
('ALQ000017', '2025-05-17', '2025-05-24', '78103921', '71590348', 1),
('ALQ000018', '2025-05-18', '2025-05-25', '79042831', '72619483', 2),
('ALQ000019', '2025-05-19', '2025-05-26', '70948132', '73105928', 1),
('ALQ000020', '2025-05-20', '2025-05-27', '79830274', '74592831', 2),
('ALQ000021', '2025-05-21', '2025-05-28', '72395801', '70918234', 1),
('ALQ000022', '2025-05-22', '2025-05-29', '78120394', '71590348', 2),
('ALQ000023', '2025-05-23', '2025-05-30', '73492816', '72619483', 1),
('ALQ000024', '2025-05-24', '2025-05-31', '79102843', '73105928', 2),
('ALQ000025', '2025-05-25', '2025-06-01', '75201934', '74592831', 1),
('ALQ000026', '2025-05-26', '2025-06-02', '74832091', '70918234', 2),
('ALQ000027', '2025-05-27', '2025-06-03', '78391042', '71590348', 1),
('ALQ000028', '2025-05-28', '2025-06-04', '72938402', '72619483', 2),
('ALQ000029', '2025-05-29', '2025-06-05', '76130294', '73105928', 1),
('ALQ000030', '2025-05-30', '2025-06-06', '79201385', '74592831', 2),
('ALQ000031', '2025-06-01', '2025-06-07', '70091824', '70918234', 1),
('ALQ000032', '2025-06-02', '2025-06-08', '77609135', '71590348', 2),
('ALQ000033', '2025-06-03', '2025-06-09', '74580912', '72619483', 1),
('ALQ000034', '2025-06-04', '2025-06-10', '77043195', '73105928', 2),
('ALQ000035', '2025-06-05', '2025-06-11', '70495821', '74592831', 1),
('ALQ000036', '2025-06-06', '2025-06-12', '78932048', '70918234', 2),
('ALQ000037', '2025-06-07', '2025-06-13', '71395820', '71590348', 1),
('ALQ000038', '2025-06-08', '2025-06-14', '73210598', '72619483', 2),
('ALQ000039', '2025-06-09', '2025-06-15', '75913208', '73105928', 1),
('ALQ000040', '2025-06-10', '2025-06-16', '79458203', '74592831', 2),
('ALQ000041', '2025-06-11', '2025-06-17', '76192834', '70918234', 1),
('ALQ000042', '2025-06-12', '2025-06-18', '72849107', '71590348', 2),
('ALQ000043', '2025-06-13', '2025-06-19', '78920431', '72619483', 1),
('ALQ000044', '2025-06-14', '2025-06-20', '74582013', '73105928', 2),
('ALQ000045', '2025-06-15', '2025-06-21', '73214098', '74592831', 1),
('ALQ000046', '2025-06-16', '2025-06-22', '76938120', '70918234', 2),
('ALQ000047', '2025-06-17', '2025-06-23', '70728190', '71590348', 1),
('ALQ000048', '2025-06-18', '2025-06-24', '78132094', '72619483', 2),
('ALQ000049', '2025-06-19', '2025-06-25', '79302184', '73105928', 1),
('ALQ000050', '2025-06-20', '2025-06-26', '70193027', '74592831', 2);

-- Inserción de Detalle_Alquiler
INSERT INTO Detalle_Alquiler (IdAlquiler, IdTraje, Cantidad) VALUES
('ALQ000001', 'T001', 2),
('ALQ000001', 'T002', 1),
('ALQ000002', 'T003', 3),
('ALQ000002', 'T004', 2),
('ALQ000003', 'T005', 1),
('ALQ000003', 'T006', 4),
('ALQ000004', 'T007', 2),
('ALQ000004', 'T008', 1),
('ALQ000005', 'T009', 1),
('ALQ000005', 'T010', 3),
('ALQ000006', 'T011', 2),
('ALQ000006', 'T012', 1),
('ALQ000007', 'T013', 4),
('ALQ000007', 'T014', 2),
('ALQ000008', 'T015', 3),
('ALQ000008', 'T016', 1),
('ALQ000009', 'T017', 2),
('ALQ000009', 'T018', 3),
('ALQ000010', 'T019', 1),
('ALQ000010', 'T020', 2),
('ALQ000011', 'T001', 1),
('ALQ000011', 'T002', 3),
('ALQ000012', 'T003', 2),
('ALQ000012', 'T004', 1),
('ALQ000013', 'T005', 4),
('ALQ000013', 'T006', 2),
('ALQ000014', 'T007', 3),
('ALQ000014', 'T008', 1),
('ALQ000015', 'T009', 1),
('ALQ000015', 'T010', 2),
('ALQ000016', 'T011', 3),
('ALQ000016', 'T012', 4),
('ALQ000017', 'T013', 2),
('ALQ000017', 'T014', 1),
('ALQ000018', 'T015', 3),
('ALQ000018', 'T016', 2),
('ALQ000019', 'T017', 4),
('ALQ000019', 'T018', 3),
('ALQ000020', 'T019', 2),
('ALQ000020', 'T020', 1),
('ALQ000021', 'T001', 2),
('ALQ000021', 'T002', 1),
('ALQ000022', 'T003', 3),
('ALQ000022', 'T004', 2),
('ALQ000023', 'T005', 1),
('ALQ000023', 'T006', 4),
('ALQ000024', 'T007', 2),
('ALQ000024', 'T008', 3),
('ALQ000025', 'T009', 1),
('ALQ000025', 'T010', 2),
('ALQ000026', 'T011', 3),
('ALQ000026', 'T012', 1),
('ALQ000027', 'T013', 4),
('ALQ000027', 'T014', 2),
('ALQ000028', 'T015', 2),
('ALQ000028', 'T016', 3),
('ALQ000029', 'T017', 1),
('ALQ000029', 'T018', 4),
('ALQ000030', 'T019', 2),
('ALQ000030', 'T020', 1),
('ALQ000031', 'T001', 2),
('ALQ000031', 'T002', 1),
('ALQ000032', 'T003', 4),
('ALQ000032', 'T004', 3),
('ALQ000033', 'T005', 2),
('ALQ000033', 'T006', 3),
('ALQ000034', 'T007', 1),
('ALQ000034', 'T008', 2),
('ALQ000035', 'T009', 3),
('ALQ000035', 'T010', 4),
('ALQ000036', 'T011', 2),
('ALQ000036', 'T012', 1),
('ALQ000037', 'T013', 3),
('ALQ000037', 'T014', 2),
('ALQ000038', 'T015', 1),
('ALQ000038', 'T016', 4),
('ALQ000039', 'T017', 2),
('ALQ000039', 'T018', 3),
('ALQ000040', 'T019', 1),
('ALQ000040', 'T020', 2),
('ALQ000041', 'T001', 3),
('ALQ000041', 'T002', 2),
('ALQ000042', 'T003', 2),
('ALQ000042', 'T004', 1),
('ALQ000043', 'T005', 4),
('ALQ000043', 'T006', 2),
('ALQ000044', 'T007', 1),
('ALQ000044', 'T008', 3),
('ALQ000045', 'T009', 2),
('ALQ000045', 'T010', 1),
('ALQ000046', 'T011', 3),
('ALQ000046', 'T012', 4),
('ALQ000047', 'T013', 2),
('ALQ000047', 'T014', 1),
('ALQ000048', 'T015', 2),
('ALQ000048', 'T016', 3),
('ALQ000049', 'T017', 4),
('ALQ000049', 'T018', 2),
('ALQ000050', 'T019', 1),
('ALQ000050', 'T020', 3);

-- Inserción de MetodoPago
INSERT INTO MetodoPago (IdMetodoPago, NombreMetodo) VALUES
('MP01', 'Pago Efectivo'),
('MP02', 'Tarjeta de Crédito'),
('MP03', 'Tarjeta de Débito'),
('MP04', 'Billeteras digitales');

-- Inserción de Pago
INSERT INTO Pago (IdPago, IdAlquiler, FechaPago, Monto, IdMetodoPago) VALUES
('PAG000001', 'ALQ000001', '2025-05-01', 125.00, 'MP01'),
('PAG000002', 'ALQ000002', '2025-05-01', 180.00, 'MP02'),
('PAG000003', 'ALQ000003', '2025-05-01', 140.00, 'MP03'),
('PAG000004', 'ALQ000004', '2025-05-02', 95.00,  'MP04'),
('PAG000005', 'ALQ000005', '2025-05-02', 210.00, 'MP01'),
('PAG000006', 'ALQ000006', '2025-05-02', 135.00, 'MP02'),
('PAG000007', 'ALQ000007', '2025-05-03', 170.00, 'MP03'),
('PAG000008', 'ALQ000008', '2025-05-03', 110.00, 'MP04'),
('PAG000009', 'ALQ000009', '2025-05-03', 195.00, 'MP01'),
('PAG000010', 'ALQ000010', '2025-05-04', 130.00, 'MP02'),
('PAG000011', 'ALQ000011', '2025-05-04', 160.00, 'MP03'),
('PAG000012', 'ALQ000012', '2025-05-04', 115.00, 'MP04'),
('PAG000013', 'ALQ000013', '2025-05-05', 220.00, 'MP01'),
('PAG000014', 'ALQ000014', '2025-05-05', 125.00, 'MP02'),
('PAG000015', 'ALQ000015', '2025-05-05', 145.00, 'MP03'),
('PAG000016', 'ALQ000016', '2025-05-06', 100.00, 'MP04'),
('PAG000017', 'ALQ000017', '2025-05-06', 205.00, 'MP01'),
('PAG000018', 'ALQ000018', '2025-05-06', 135.00, 'MP02'),
('PAG000019', 'ALQ000019', '2025-05-07', 150.00, 'MP03'),
('PAG000020', 'ALQ000020', '2025-05-07', 90.00,  'MP04'),
('PAG000021', 'ALQ000021', '2025-05-07', 175.00, 'MP01'),
('PAG000022', 'ALQ000022', '2025-05-08', 200.00, 'MP02'),
('PAG000023', 'ALQ000023', '2025-05-08', 120.00, 'MP03'),
('PAG000024', 'ALQ000024', '2025-05-08', 105.00, 'MP04'),
('PAG000025', 'ALQ000025', '2025-05-09', 145.00, 'MP01'),
('PAG000026', 'ALQ000026', '2025-05-09', 160.00, 'MP02'),
('PAG000027', 'ALQ000027', '2025-05-09', 180.00, 'MP03'),
('PAG000028', 'ALQ000028', '2025-05-10', 100.00, 'MP04'),
('PAG000029', 'ALQ000029', '2025-05-10', 215.00, 'MP01'),
('PAG000030', 'ALQ000030', '2025-05-10', 135.00, 'MP02'),
('PAG000031', 'ALQ000031', '2025-05-11', 165.00, 'MP03'),
('PAG000032', 'ALQ000032', '2025-05-11', 110.00, 'MP04'),
('PAG000033', 'ALQ000033', '2025-05-11', 185.00, 'MP01'),
('PAG000034', 'ALQ000034', '2025-05-12', 140.00, 'MP02'),
('PAG000035', 'ALQ000035', '2025-05-12', 125.00, 'MP03'),
('PAG000036', 'ALQ000036', '2025-05-12', 90.00,  'MP04'),
('PAG000037', 'ALQ000037', '2025-05-13', 200.00, 'MP01'),
('PAG000038', 'ALQ000038', '2025-05-13', 150.00, 'MP02'),
('PAG000039', 'ALQ000039', '2025-05-13', 100.00, 'MP03'),
('PAG000040', 'ALQ000040', '2025-05-14', 175.00, 'MP04'),
('PAG000041', 'ALQ000041', '2025-05-14', 115.00, 'MP01'),
('PAG000042', 'ALQ000042', '2025-05-14', 130.00, 'MP02'),
('PAG000043', 'ALQ000043', '2025-05-15', 90.00,  'MP03'),
('PAG000044', 'ALQ000044', '2025-05-15', 160.00, 'MP04'),
('PAG000045', 'ALQ000045', '2025-05-15', 190.00, 'MP01'),
('PAG000046', 'ALQ000046', '2025-05-15', 150.00, 'MP02'),
('PAG000047', 'ALQ000047', '2025-05-15', 100.00, 'MP03'),
('PAG000048', 'ALQ000048', '2025-05-15', 135.00, 'MP04'),
('PAG000049', 'ALQ000049', '2025-05-15', 125.00, 'MP01'),
('PAG000050', 'ALQ000050', '2025-05-15', 200.00, 'MP02');










