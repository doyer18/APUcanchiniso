
-- ===============================TABLA PAGO===============================
USE ApuCanchiniso;
GO

-- Listar Pagos
IF OBJECT_ID('spListarPago', 'P') IS NOT NULL
    DROP PROC spListarPago;
GO
CREATE PROC spListarPago
AS
BEGIN
    SELECT IdPago, IdAlquiler, Monto, FechaPago, IdMetodoPago
    FROM Pago;
END;
GO

-- Agregar Pago
IF OBJECT_ID('spAgregarPago', 'P') IS NOT NULL
    DROP PROC spAgregarPago;
GO
CREATE PROC spAgregarPago
    @IdPago VARCHAR(11),
    @IdAlquiler VARCHAR(11),
    @Monto DECIMAL(7,2),
    @FechaPago DATE,
    @IdMetodoPago VARCHAR(4)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Pago WHERE IdPago = @IdPago)
    BEGIN
        -- Verificar llaves for�neas: Alquiler, MetodoPago
        IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
        BEGIN
            SELECT CodError = 2, Mensaje = 'Error: Alquiler no existe';
            RETURN;
        END
        IF NOT EXISTS (SELECT 1 FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago)
        BEGIN
            SELECT CodError = 3, Mensaje = 'Error: MetodoPago no existe';
            RETURN;
        END

        INSERT INTO Pago (IdPago, IdAlquiler, Monto, FechaPago, IdMetodoPago)
        VALUES (@IdPago, @IdAlquiler, @Monto, @FechaPago, @IdMetodoPago);
        SELECT CodError = 0, Mensaje = 'Pago agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Pago ya existe';
END;
GO

-- Obtener Pago por IdPago
IF OBJECT_ID('spGetPagoId', 'P') IS NOT NULL
    DROP PROC spGetPagoId;
GO
CREATE PROC spGetPagoId
    @IdPago VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Pago WHERE IdPago = @IdPago)
        SELECT * FROM Pago WHERE IdPago = @IdPago;
    ELSE
        SELECT CodError = 1, Mensaje = 'Pago no encontrado';
END;
GO

-- Actualizar Pago
IF OBJECT_ID('spActualizarPago', 'P') IS NOT NULL
    DROP PROC spActualizarPago;
GO
CREATE PROC spActualizarPago
    @IdPago VARCHAR(11),
    @IdAlquiler VARCHAR(11),
    @Monto DECIMAL(7,2),
    @FechaPago DATE,
    @IdMetodoPago VARCHAR(4)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Pago WHERE IdPago = @IdPago)
    BEGIN
        -- Verificar llaves for�neas
        IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
        BEGIN
            SELECT CodError = 2, Mensaje = 'Error: Alquiler no existe';
            RETURN;
        END
        IF NOT EXISTS (SELECT 1 FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago)
        BEGIN
            SELECT CodError = 3, Mensaje = 'Error: MetodoPago no existe';
            RETURN;
        END

        UPDATE Pago
        SET IdAlquiler = @IdAlquiler,
            Monto = @Monto,
            FechaPago = @FechaPago,
            IdMetodoPago = @IdMetodoPago
        WHERE IdPago = @IdPago;
        SELECT CodError = 0, Mensaje = 'Pago actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Pago no existe';
END;
GO

-- Eliminar Pago
IF OBJECT_ID('spEliminarPago', 'P') IS NOT NULL
    DROP PROC spEliminarPago;
GO
CREATE PROC spEliminarPago
    @IdPago VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Pago WHERE IdPago = @IdPago)
    BEGIN
        DELETE FROM Pago WHERE IdPago = @IdPago;
        SELECT CodError = 0, Mensaje = 'Pago eliminado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Pago no existe';
END;
GO

-- Ejemplos para Pago
EXEC spAgregarPago 'PAG000051', 'ALQ000001', 100.00, '2025-06-01', 'MP01';
EXEC spListarPago;
EXEC spGetPagoId 'PAG000009';
EXEC spActualizarPago 'PAG000051', 'ALQ000001', 120.00, '2025-06-02', 'MP01';
EXEC spEliminarPago 'PAG000051';