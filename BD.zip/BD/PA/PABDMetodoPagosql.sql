
-- ===============================TABLA METODOPAGO===============================
USE ApuCanchiniso;
GO

-- Listar MetodoPago
IF OBJECT_ID('spListarMetodoPago', 'P') IS NOT NULL
    DROP PROC spListarMetodoPago;
GO
CREATE PROC spListarMetodoPago
AS
BEGIN
    SELECT IdMetodoPago, NombreMetodo
    FROM MetodoPago;
END;
GO

-- Agregar MetodoPago
IF OBJECT_ID('spAgregarMetodoPago', 'P') IS NOT NULL
    DROP PROC spAgregarMetodoPago;
GO
CREATE PROC spAgregarMetodoPago
    @IdMetodoPago VARCHAR(4),
    @NombreMetodo NVARCHAR(50)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago)
    BEGIN
        INSERT INTO MetodoPago (IdMetodoPago, NombreMetodo)
        VALUES (@IdMetodoPago, @NombreMetodo);
        SELECT CodError = 0, Mensaje = 'MetodoPago agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: MetodoPago ya existe';
END;
GO

-- Obtener MetodoPago por IdMetodoPago
IF OBJECT_ID('spGetMetodoPagoId', 'P') IS NOT NULL
    DROP PROC spGetMetodoPagoId;
GO
CREATE PROC spGetMetodoPagoId
    @IdMetodoPago VARCHAR(4)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago)
        SELECT * FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago;
    ELSE
        SELECT CodError = 1, Mensaje = 'MetodoPago no encontrado';
END;
GO

-- Actualizar MetodoPago
IF OBJECT_ID('spActualizarMetodoPago', 'P') IS NOT NULL
    DROP PROC spActualizarMetodoPago;
GO
CREATE PROC spActualizarMetodoPago
    @IdMetodoPago VARCHAR(4),
    @NombreMetodo NVARCHAR(50)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago)
    BEGIN
        UPDATE MetodoPago
        SET NombreMetodo = @NombreMetodo
        WHERE IdMetodoPago = @IdMetodoPago;
        SELECT CodError = 0, Mensaje = 'MetodoPago actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: MetodoPago no existe';
END;
GO

-- Eliminar MetodoPago
IF OBJECT_ID('spEliminarMetodoPago', 'P') IS NOT NULL
    DROP PROC spEliminarMetodoPago;
GO
CREATE PROC spEliminarMetodoPago
    @IdMetodoPago VARCHAR(4)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago)
    BEGIN
        -- Verificar que no existan Pago asociados
        IF NOT EXISTS (SELECT 1 FROM Pago WHERE IdMetodoPago = @IdMetodoPago)
        BEGIN
            DELETE FROM MetodoPago WHERE IdMetodoPago = @IdMetodoPago;
            SELECT CodError = 0, Mensaje = 'MetodoPago eliminado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Existen Pagos asociados a este MetodoPago';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: MetodoPago no existe';
END;
GO

-- Ejemplos para MetodoPago
EXEC spAgregarMetodoPago 'MP05', 'Pago Ejemplo';
EXEC spListarMetodoPago;
EXEC spGetMetodoPagoId 'MP01';
EXEC spActualizarMetodoPago 'MP05', 'Pago Ejemplo Modificado';
EXEC spEliminarMetodoPago 'MP05';