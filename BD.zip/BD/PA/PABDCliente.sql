
-- ===============================TABLA CLIENTE===============================

USE ApuCanchiniso;
GO

-- Listar Clientes
IF OBJECT_ID('spListarCliente', 'P') IS NOT NULL
    DROP PROC spListarCliente;
GO
CREATE PROC spListarCliente
AS
BEGIN
    SELECT IdCliente, cliNombres, cliApePaterno, cliApeMaterno, Telefono, Email, Usuario, Password
    FROM Cliente;
END;
GO

-- Agregar Cliente
IF OBJECT_ID('spAgregarCliente', 'P') IS NOT NULL
    DROP PROC spAgregarCliente;
GO
CREATE PROC spAgregarCliente
    @IdCliente VARCHAR(10),
    @cliNombres VARCHAR(100),
    @cliApePaterno VARCHAR(30),
    @cliApeMaterno VARCHAR(30) = NULL,
    @Telefono VARCHAR(20) = NULL,
    @Email VARCHAR(100) = NULL,
    @Usuario VARCHAR(50),
    @Password VARCHAR(100)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Cliente WHERE IdCliente = @IdCliente)
    BEGIN
        INSERT INTO Cliente (IdCliente, cliNombres, cliApePaterno, cliApeMaterno, Telefono, Email, Usuario, Password)
        VALUES (@IdCliente, @cliNombres, @cliApePaterno, @cliApeMaterno, @Telefono, @Email, @Usuario, @Password);
        SELECT CodError = 0, Mensaje = 'Cliente agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Cliente ya existe';
END;
GO

-- Obtener Cliente por IdCliente
IF OBJECT_ID('spGetClienteId', 'P') IS NOT NULL
    DROP PROC spGetClienteId;
GO
CREATE PROC spGetClienteId
    @IdCliente VARCHAR(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Cliente WHERE IdCliente = @IdCliente)
        SELECT * FROM Cliente WHERE IdCliente = @IdCliente;
    ELSE
        SELECT CodError = 1, Mensaje = 'Cliente no encontrado';
END;
GO

-- Actualizar Cliente
IF OBJECT_ID('spActualizarCliente', 'P') IS NOT NULL
    DROP PROC spActualizarCliente;
GO
CREATE PROC spActualizarCliente
    @IdCliente VARCHAR(10),
    @cliNombres VARCHAR(100),
    @cliApePaterno VARCHAR(30),
    @cliApeMaterno VARCHAR(30) = NULL,
    @Telefono VARCHAR(20) = NULL,
    @Email VARCHAR(100) = NULL,
    @Usuario VARCHAR(50),
    @Password VARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Cliente WHERE IdCliente = @IdCliente)
    BEGIN
        UPDATE Cliente
        SET cliNombres = @cliNombres,
            cliApePaterno = @cliApePaterno,
            cliApeMaterno = @cliApeMaterno,
            Telefono = @Telefono,
            Email = @Email,
            Usuario = @Usuario,
            Password = @Password
        WHERE IdCliente = @IdCliente;
        SELECT CodError = 0, Mensaje = 'Cliente actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Cliente no existe';
END;
GO

-- Eliminar Cliente
IF OBJECT_ID('spEliminarCliente', 'P') IS NOT NULL
    DROP PROC spEliminarCliente;
GO
CREATE PROC spEliminarCliente
    @IdCliente VARCHAR(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Cliente WHERE IdCliente = @IdCliente)
    BEGIN
        -- Verificar que no existan Alquiler asociados
        IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE IdCliente = @IdCliente)
        BEGIN
            DELETE FROM Cliente WHERE IdCliente = @IdCliente;
            SELECT CodError = 0, Mensaje = 'Cliente eliminado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Existen Alquileres asociados a este Cliente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Cliente no existe';
END;
GO


-- Ejemplos para Cliente
EXEC spAgregarCliente 'C00051', 'Nombre', 'ApellidoP', 'ApellidoM', '912345678', 'email@dominio.com', 'usuario51', 'claveSegura';
EXEC spListarCliente;
EXEC spGetClienteId 'C00051';
EXEC spActualizarCliente 'C00051', 'NombreMod', 'ApellidoP', 'ApellidoM', '912345678', 'email@dominio.com', 'usuario51', 'nuevaClave';
EXEC spEliminarCliente 'C00051';