
-- ===============================TABLA DETALLEALQUILER===============================
USE ApuCanchiniso;
GO

-- Listar Detalles de Alquiler
IF OBJECT_ID('spListarDetalleAlquiler', 'P') IS NOT NULL
    DROP PROC spListarDetalleAlquiler;
GO
CREATE PROC spListarDetalleAlquiler
AS
BEGIN
    SELECT IdAlquiler, IdTraje, Cantidad
    FROM Detalle_Alquiler;
END;
GO

-- Agregar Detalle_Alquiler
IF OBJECT_ID('spAgregarDetalleAlquiler', 'P') IS NOT NULL
    DROP PROC spAgregarDetalleAlquiler;
GO
CREATE PROC spAgregarDetalleAlquiler
    @IdAlquiler VARCHAR(11),
    @IdTraje VARCHAR(11),
    @Cantidad INT
AS
BEGIN
    -- Verificar existencia de Alquiler y Traje
    IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
    BEGIN
        SELECT CodError = 2, Mensaje = 'Error: Alquiler no existe';
        RETURN;
    END
    IF NOT EXISTS (SELECT 1 FROM Traje WHERE IdTraje = @IdTraje)
    BEGIN
        SELECT CodError = 3, Mensaje = 'Error: Traje no existe';
        RETURN;
    END
    -- Verificar no duplicar par PK
    IF NOT EXISTS (SELECT 1 FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje)
    BEGIN
        INSERT INTO Detalle_Alquiler (IdAlquiler, IdTraje, Cantidad)
        VALUES (@IdAlquiler, @IdTraje, @Cantidad);
        SELECT CodError = 0, Mensaje = 'Detalle de Alquiler agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Detalle ya existe para ese Alquiler y Traje';
END;
GO

-- Obtener Detalle_Alquiler por IdAlquiler y IdTraje
IF OBJECT_ID('spGetDetalleAlquiler', 'P') IS NOT NULL
    DROP PROC spGetDetalleAlquiler;
GO
CREATE PROC spGetDetalleAlquiler
    @IdAlquiler VARCHAR(11),
    @IdTraje VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje)
        SELECT * FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje;
    ELSE
        SELECT CodError = 1, Mensaje = 'Detalle de Alquiler no encontrado';
END;
GO

-- Actualizar Detalle_Alquiler
IF OBJECT_ID('spActualizarDetalleAlquiler', 'P') IS NOT NULL
    DROP PROC spActualizarDetalleAlquiler;
GO
CREATE PROC spActualizarDetalleAlquiler
    @IdAlquiler VARCHAR(11),
    @IdTraje VARCHAR(11),
    @Cantidad INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje)
    BEGIN
        UPDATE Detalle_Alquiler
        SET Cantidad = @Cantidad
        WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje;
        SELECT CodError = 0, Mensaje = 'Detalle de Alquiler actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Detalle no existe';
END;
GO

-- Eliminar Detalle_Alquiler
IF OBJECT_ID('spEliminarDetalleAlquiler', 'P') IS NOT NULL
    DROP PROC spEliminarDetalleAlquiler;
GO
CREATE PROC spEliminarDetalleAlquiler
    @IdAlquiler VARCHAR(11),
    @IdTraje VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje)
    BEGIN
        DELETE FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler AND IdTraje = @IdTraje;
        SELECT CodError = 0, Mensaje = 'Detalle de Alquiler eliminado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Detalle no existe';
END;
GO

-- Ejemplos para Detalle_Alquiler
EXEC spAgregarDetalleAlquiler 'ALQ000050', 'T001', 2;
EXEC spListarDetalleAlquiler;
EXEC spGetDetalleAlquiler 'ALQ000001', 'T003';
EXEC spActualizarDetalleAlquiler 'ALQ000050', 'T001', 3;
EXEC spEliminarDetalleAlquiler 'ALQ000050', 'T001';
