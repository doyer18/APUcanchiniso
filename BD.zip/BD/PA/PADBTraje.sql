
-- ===============================TABLA TRAJE===============================
USE APUCanchiniso;
GO

-- Listar Trajes
IF OBJECT_ID('spListarTraje', 'P') IS NOT NULL
    DROP PROC spListarTraje;
GO
CREATE PROC spListarTraje
AS
BEGIN
    SELECT IdTraje, NombreTraje, Descripcion, Talla, Stock, PrecioAlquiler, Imagen, RUC
    FROM Traje;
END;
GO

-- Agregar Traje
IF OBJECT_ID('spAgregarTraje', 'P') IS NOT NULL
    DROP PROC spAgregarTraje;
GO
CREATE PROC spAgregarTraje
    @IdTraje VARCHAR(11),
    @NombreTraje VARCHAR(100),
    @Descripcion VARCHAR(255),
    @Talla VARCHAR(15) = NULL,
    @Stock INT,
    @PrecioAlquiler DECIMAL(7,2),
    @Imagen VARCHAR(255),
    @RUC VARCHAR(11)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Traje WHERE IdTraje = @IdTraje)
    BEGIN
        -- Verificar que exista Proveedor
        IF EXISTS (SELECT 1 FROM Proveedor WHERE RUC = @RUC)
        BEGIN
            INSERT INTO Traje (IdTraje, NombreTraje, Descripcion, Talla, Stock, PrecioAlquiler, Imagen, RUC)
            VALUES (@IdTraje, @NombreTraje, @Descripcion, @Talla, @Stock, @PrecioAlquiler, @Imagen, @RUC);
            SELECT CodError = 0, Mensaje = 'Traje agregado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Proveedor no existe';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Traje ya existe';
END;
GO

-- Obtener Traje por IdTraje
IF OBJECT_ID('spGetTrajeId', 'P') IS NOT NULL
    DROP PROC spGetTrajeId;
GO
CREATE PROC spGetTrajeId
    @IdTraje VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Traje WHERE IdTraje = @IdTraje)
        SELECT t.*, p.provNombre 
        FROM Traje t
        LEFT JOIN Proveedor p ON t.RUC = p.RUC
        WHERE t.IdTraje = @IdTraje;
    ELSE
        SELECT CodError = 1, Mensaje = 'Traje no encontrado';
END;
GO

-- Actualizar Traje
IF OBJECT_ID('spActualizarTraje', 'P') IS NOT NULL
    DROP PROC spActualizarTraje;
GO
CREATE PROC spActualizarTraje
    @IdTraje VARCHAR(11),
    @NombreTraje VARCHAR(100),
    @Descripcion VARCHAR(255),
    @Talla VARCHAR(15) = NULL,
    @Stock INT,
    @PrecioAlquiler DECIMAL(7,2),
    @Imagen VARCHAR(255),
    @RUC VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Traje WHERE IdTraje = @IdTraje)
    BEGIN
        -- Verificar que exista Proveedor
        IF EXISTS (SELECT 1 FROM Proveedor WHERE RUC = @RUC)
        BEGIN
            UPDATE Traje
            SET NombreTraje = @NombreTraje,
                Descripcion = @Descripcion,
                Talla = @Talla,
                Stock = @Stock,
                PrecioAlquiler = @PrecioAlquiler,
                Imagen = @Imagen,
                RUC = @RUC
            WHERE IdTraje = @IdTraje;
            SELECT CodError = 0, Mensaje = 'Traje actualizado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Proveedor no existe';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Traje no existe';
END;
GO

-- Eliminar Traje
IF OBJECT_ID('spEliminarTraje', 'P') IS NOT NULL
    DROP PROC spEliminarTraje;
GO
CREATE PROC spEliminarTraje
    @IdTraje VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Traje WHERE IdTraje = @IdTraje)
    BEGIN
        -- Verificar que no existan Detalle_Alquiler asociados
        IF NOT EXISTS (SELECT 1 FROM Detalle_Alquiler WHERE IdTraje = @IdTraje)
        BEGIN
            DELETE FROM Traje WHERE IdTraje = @IdTraje;
            SELECT CodError = 0, Mensaje = 'Traje eliminado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Existen Detalles de Alquiler que usan este Traje';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Traje no existe';
END;
GO

-- Ejemplos para Traje
EXEC spAgregarTraje 'T021', 'Traje Ejemplo', 'Descripci�n ejemplo', 'M', 5, 30.00, '/img/ejemplo.jpg', '20123456789';
EXEC spListarTraje;
EXEC spGetTrajeId 'T001';
EXEC spActualizarTraje 'T021', 'Traje Ejemplo 2', 'Nueva descripci�n', 'L', 6, 35.00, '/img/ejemplo2.jpg', '20123456789';
EXEC spEliminarTraje 'T021';