
-- ===============================TABLA TIPOCOMPROBANTE===============================
USE ApuCanchiniso;
GO

-- Listar TipoComprobante
IF OBJECT_ID('spListarTipoComprobante', 'P') IS NOT NULL
    DROP PROC spListarTipoComprobante;
GO
CREATE PROC spListarTipoComprobante
AS
BEGIN
    SELECT IdTipoComprobante, NombreTipo
    FROM TipoComprobante;
END;
GO

-- Agregar TipoComprobante
IF OBJECT_ID('spAgregarTipoComprobante', 'P') IS NOT NULL
    DROP PROC spAgregarTipoComprobante;
GO
CREATE PROC spAgregarTipoComprobante
    @IdTipoComprobante INT,
    @NombreTipo NVARCHAR(50)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante)
    BEGIN
        INSERT INTO TipoComprobante (IdTipoComprobante, NombreTipo)
        VALUES (@IdTipoComprobante, @NombreTipo);
        SELECT CodError = 0, Mensaje = 'TipoComprobante agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: TipoComprobante ya existe';
END;
GO

-- Obtener TipoComprobante por IdTipoComprobante
IF OBJECT_ID('spGetTipoComprobanteId', 'P') IS NOT NULL
    DROP PROC spGetTipoComprobanteId;
GO
CREATE PROC spGetTipoComprobanteId
    @IdTipoComprobante INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante)
        SELECT * FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante;
    ELSE
        SELECT CodError = 1, Mensaje = 'TipoComprobante no encontrado';
END;
GO

-- Actualizar TipoComprobante
IF OBJECT_ID('spActualizarTipoComprobante', 'P') IS NOT NULL
    DROP PROC spActualizarTipoComprobante;
GO
CREATE PROC spActualizarTipoComprobante
    @IdTipoComprobante INT,
    @NombreTipo NVARCHAR(50)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante)
    BEGIN
        UPDATE TipoComprobante
        SET NombreTipo = @NombreTipo
        WHERE IdTipoComprobante = @IdTipoComprobante;
        SELECT CodError = 0, Mensaje = 'TipoComprobante actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: TipoComprobante no existe';
END;
GO

-- Eliminar TipoComprobante
IF OBJECT_ID('spEliminarTipoComprobante', 'P') IS NOT NULL
    DROP PROC spEliminarTipoComprobante;
GO
CREATE PROC spEliminarTipoComprobante
    @IdTipoComprobante INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante)
    BEGIN
        -- Verificar que no existan Alquiler asociados
        IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE IdTipoComprobante = @IdTipoComprobante)
        BEGIN
            DELETE FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante;
            SELECT CodError = 0, Mensaje = 'TipoComprobante eliminado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Existen Alquileres asociados a este TipoComprobante';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: TipoComprobante no existe';
END;
GO

-- Ejemplos para TipoComprobante
EXEC spAgregarTipoComprobante 3, 'Recibo';
EXEC spListarTipoComprobante;
EXEC spGetTipoComprobanteId 3;
EXEC spActualizarTipoComprobante 3, 'Recibo Modificado';
EXEC spEliminarTipoComprobante 3;