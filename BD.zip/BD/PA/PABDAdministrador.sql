-- procedimiento almacenado para TAdministrador
-- autor : grupo x
-- 12/06/2025

-- ===============================TABLA ADMINISTRADOR===============================
USE ApuCanchiniso;
GO

-- Listar Administradores
IF OBJECT_ID('spListarAdministrador', 'P') IS NOT NULL
    DROP PROC spListarAdministrador;
GO
CREATE PROC spListarAdministrador
AS
BEGIN
    SELECT DNI, NombreAdministrador, Usuario, Password
    FROM Administrador;
END;
GO

-- Agregar Administrador
IF OBJECT_ID('spAgregarAdministrador', 'P') IS NOT NULL
    DROP PROC spAgregarAdministrador;
GO
CREATE PROC spAgregarAdministrador
    @DNI VARCHAR(10),
    @NombreAdministrador NVARCHAR(100),
    @Usuario NVARCHAR(50),
    @Password NVARCHAR(100)
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Administrador WHERE DNI = @DNI)
    BEGIN
        INSERT INTO Administrador (DNI, NombreAdministrador, Usuario, Password)
        VALUES (@DNI, @NombreAdministrador, @Usuario, @Password);
        SELECT CodError = 0, Mensaje = 'Administrador agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Administrador ya existe';
END;
GO

-- Obtener Administrador por DNI
IF OBJECT_ID('spGetAdministradorDNI', 'P') IS NOT NULL
    DROP PROC spGetAdministradorDNI;
GO
CREATE PROC spGetAdministradorDNI
    @DNI VARCHAR(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Administrador WHERE DNI = @DNI)
        SELECT * FROM Administrador WHERE DNI = @DNI;
    ELSE
        SELECT CodError = 1, Mensaje = 'Administrador no encontrado';
END;
GO

-- Actualizar Administrador
IF OBJECT_ID('spActualizarAdministrador', 'P') IS NOT NULL
    DROP PROC spActualizarAdministrador;
GO
CREATE PROC spActualizarAdministrador
    @DNI VARCHAR(10),
    @NombreAdministrador NVARCHAR(100),
    @Usuario NVARCHAR(50),
    @Password NVARCHAR(100)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Administrador WHERE DNI = @DNI)
    BEGIN
        UPDATE Administrador
        SET NombreAdministrador = @NombreAdministrador,
            Usuario = @Usuario,
            Password = @Password
        WHERE DNI = @DNI;
        SELECT CodError = 0, Mensaje = 'Administrador actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Administrador no existe';
END;
GO

-- Eliminar Administrador
IF OBJECT_ID('spEliminarAdministrador', 'P') IS NOT NULL
    DROP PROC spEliminarAdministrador;
GO
CREATE PROC spEliminarAdministrador
    @DNI VARCHAR(10)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Administrador WHERE DNI = @DNI)
    BEGIN
        -- Verificar que no existan Alquiler asociados
        IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE DNI = @DNI)
        BEGIN
            DELETE FROM Administrador WHERE DNI = @DNI;
            SELECT CodError = 0, Mensaje = 'Administrador eliminado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Existen Alquileres asociados a este Administrador';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Administrador no existe';
END;
GO

-- Ejemplos para Administrador
EXEC spAgregarAdministrador '70999999', 'Admin Ejemplo', 'adminUser', 'pass123';
EXEC spListarAdministrador;
EXEC spGetAdministradorDNI '70999999';
EXEC spActualizarAdministrador '70999999', 'Admin Modificado', 'adminUser2', 'pass456';
EXEC spEliminarAdministrador '70999999';