
-- ===============================TABLA ALQUILER===============================
USE ApuCanchiniso;
GO

-- Listar Alquileres
IF OBJECT_ID('spListarAlquiler', 'P') IS NOT NULL
    DROP PROC spListarAlquiler;
GO
CREATE PROC spListarAlquiler
AS
BEGIN
    SELECT IdAlquiler, FechaAlquiler, FechaDevolucion, IdCliente, DNI, IdTipoComprobante
    FROM Alquiler;
END;
GO

-- Agregar Alquiler
IF OBJECT_ID('spAgregarAlquiler', 'P') IS NOT NULL
    DROP PROC spAgregarAlquiler;
GO
CREATE PROC spAgregarAlquiler
    @IdAlquiler VARCHAR(11),
    @FechaAlquiler DATE,
    @FechaDevolucion DATE = NULL,
    @IdCliente VARCHAR(10),
    @DNI VARCHAR(10),
    @IdTipoComprobante INT
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
    BEGIN
        -- Verificar llaves for�neas: Cliente, Administrador, TipoComprobante
        IF NOT EXISTS (SELECT 1 FROM Cliente WHERE IdCliente = @IdCliente)
        BEGIN
            SELECT CodError = 2, Mensaje = 'Error: Cliente no existe';
            RETURN;
        END
        IF NOT EXISTS (SELECT 1 FROM Administrador WHERE DNI = @DNI)
        BEGIN
            SELECT CodError = 3, Mensaje = 'Error: Administrador no existe';
            RETURN;
        END
        IF NOT EXISTS (SELECT 1 FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante)
        BEGIN
            SELECT CodError = 4, Mensaje = 'Error: TipoComprobante no existe';
            RETURN;
        END

        INSERT INTO Alquiler (IdAlquiler, FechaAlquiler, FechaDevolucion, IdCliente, DNI, IdTipoComprobante)
        VALUES (@IdAlquiler, @FechaAlquiler, @FechaDevolucion, @IdCliente, @DNI, @IdTipoComprobante);
        SELECT CodError = 0, Mensaje = 'Alquiler agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Alquiler ya existe';
END;
GO

-- Obtener Alquiler por IdAlquiler
IF OBJECT_ID('spGetAlquilerId', 'P') IS NOT NULL
    DROP PROC spGetAlquilerId;
GO
CREATE PROC spGetAlquilerId
    @IdAlquiler VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
        SELECT a.*, c.cliNombres, c.cliApePaterno, ad.NombreAdministrador, t.NombreTipo
        FROM Alquiler a
        LEFT JOIN Cliente c ON a.IdCliente = c.IdCliente
        LEFT JOIN Administrador ad ON a.DNI = ad.DNI
        LEFT JOIN TipoComprobante t ON a.IdTipoComprobante = t.IdTipoComprobante
        WHERE a.IdAlquiler = @IdAlquiler;
    ELSE
        SELECT CodError = 1, Mensaje = 'Alquiler no encontrado';
END;
GO

-- Actualizar Alquiler
IF OBJECT_ID('spActualizarAlquiler', 'P') IS NOT NULL
    DROP PROC spActualizarAlquiler;
GO
CREATE PROC spActualizarAlquiler
    @IdAlquiler VARCHAR(11),
    @FechaAlquiler DATE,
    @FechaDevolucion DATE = NULL,
    @IdCliente VARCHAR(10),
    @DNI VARCHAR(10),
    @IdTipoComprobante INT
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
    BEGIN
        -- Verificar llaves for�neas
        IF NOT EXISTS (SELECT 1 FROM Cliente WHERE IdCliente = @IdCliente)
        BEGIN
            SELECT CodError = 2, Mensaje = 'Error: Cliente no existe';
            RETURN;
        END
        IF NOT EXISTS (SELECT 1 FROM Administrador WHERE DNI = @DNI)
        BEGIN
            SELECT CodError = 3, Mensaje = 'Error: Administrador no existe';
            RETURN;
        END
        IF NOT EXISTS (SELECT 1 FROM TipoComprobante WHERE IdTipoComprobante = @IdTipoComprobante)
        BEGIN
            SELECT CodError = 4, Mensaje = 'Error: TipoComprobante no existe';
            RETURN;
        END

        UPDATE Alquiler
        SET FechaAlquiler = @FechaAlquiler,
            FechaDevolucion = @FechaDevolucion,
            IdCliente = @IdCliente,
            DNI = @DNI,
            IdTipoComprobante = @IdTipoComprobante
        WHERE IdAlquiler = @IdAlquiler;
        SELECT CodError = 0, Mensaje = 'Alquiler actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Alquiler no existe';
END;
GO

-- Eliminar Alquiler
IF OBJECT_ID('spEliminarAlquiler', 'P') IS NOT NULL
    DROP PROC spEliminarAlquiler;
GO
CREATE PROC spEliminarAlquiler
    @IdAlquiler VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Alquiler WHERE IdAlquiler = @IdAlquiler)
    BEGIN
        -- Verificar que no existan Detalle_Alquiler o Pago asociados
        IF EXISTS (SELECT 1 FROM Detalle_Alquiler WHERE IdAlquiler = @IdAlquiler)
        BEGIN
            SELECT CodError = 2, Mensaje = 'Error: Existen Detalles de Alquiler asociados';
            RETURN;
        END
        IF EXISTS (SELECT 1 FROM Pago WHERE IdAlquiler = @IdAlquiler)
        BEGIN
            SELECT CodError = 3, Mensaje = 'Error: Existen Pagos asociados';
            RETURN;
        END

        DELETE FROM Alquiler WHERE IdAlquiler = @IdAlquiler;
        SELECT CodError = 0, Mensaje = 'Alquiler eliminado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Alquiler no existe';
END;
GO


-- Ejemplos para Alquiler
EXEC spAgregarAlquiler 'ALQ000051', '2025-07-01', '2025-07-05', '76591834', '70918234', 1;
EXEC spListarAlquiler;
EXEC spGetAlquilerId 'ALQ000001';
EXEC spActualizarAlquiler 'ALQ000051', '2025-07-02', '2025-07-06', '76591834', '70918234', 1;
EXEC spEliminarAlquiler 'ALQ000051';