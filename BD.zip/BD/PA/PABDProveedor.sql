
-- ===============================TABLA PROVEEDOR===============================
USE ApuCanchiniso;
GO

-- Listar Proveedores
IF OBJECT_ID('spListarProveedor', 'P') IS NOT NULL
    DROP PROC spListarProveedor;
GO
CREATE PROC spListarProveedor
AS
BEGIN
    SELECT RUC, provNombre, provTelefono, provEmail
    FROM Proveedor;
END;
GO

-- Agregar Proveedor
IF OBJECT_ID('spAgregarProveedor', 'P') IS NOT NULL
    DROP PROC spAgregarProveedor;
GO
CREATE PROC spAgregarProveedor
    @RUC VARCHAR(11), @provNombre VARCHAR(100), @provTelefono VARCHAR(20) = NULL, @provEmail VARCHAR(100) = NULL
AS
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Proveedor WHERE RUC = @RUC)
    BEGIN
        INSERT INTO Proveedor (RUC, provNombre, provTelefono, provEmail)
        VALUES (@RUC, @provNombre, @provTelefono, @provEmail);
        SELECT CodError = 0, Mensaje = 'Proveedor agregado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Proveedor ya existe';
END;
GO

-- Obtener Proveedor por RUC
IF OBJECT_ID('spGetProveedorRUC', 'P') IS NOT NULL
    DROP PROC spGetProveedorRUC;
GO
CREATE PROC spGetProveedorRUC
    @RUC VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Proveedor WHERE RUC = @RUC)
        SELECT * FROM Proveedor WHERE RUC = @RUC;
    ELSE
        SELECT CodError = 1, Mensaje = 'Proveedor no encontrado';
END;
GO

-- Actualizar Proveedor
IF OBJECT_ID('spActualizarProveedor', 'P') IS NOT NULL
    DROP PROC spActualizarProveedor;
GO
CREATE PROC spActualizarProveedor
    @RUC VARCHAR(11),
    @provNombre VARCHAR(100),
    @provTelefono VARCHAR(20) = NULL,
    @provEmail VARCHAR(100) = NULL
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Proveedor WHERE RUC = @RUC)
    BEGIN
        UPDATE Proveedor
        SET provNombre = @provNombre,
            provTelefono = @provTelefono,
            provEmail = @provEmail
        WHERE RUC = @RUC;
        SELECT CodError = 0, Mensaje = 'Proveedor actualizado correctamente';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Proveedor no existe';
END;
GO

-- Eliminar Proveedor
IF OBJECT_ID('spEliminarProveedor', 'P') IS NOT NULL
    DROP PROC spEliminarProveedor;
GO
CREATE PROC spEliminarProveedor
    @RUC VARCHAR(11)
AS
BEGIN
    IF EXISTS (SELECT 1 FROM Proveedor WHERE RUC = @RUC)
    BEGIN
        -- Verificar que no existan Traje asociados
        IF NOT EXISTS (SELECT 1 FROM Traje WHERE RUC = @RUC)
        BEGIN
            DELETE FROM Proveedor WHERE RUC = @RUC;
            SELECT CodError = 0, Mensaje = 'Proveedor eliminado correctamente';
        END
        ELSE
            SELECT CodError = 2, Mensaje = 'Error: Existen Trajes asociados a este Proveedor';
    END
    ELSE
        SELECT CodError = 1, Mensaje = 'Error: Proveedor no existe';
END;
GO

-- Ejemplos para Proveedor
EXEC spAgregarProveedor '20678901234', 'Nuevo Proveedor', '084000000', 'nuevo@proveedor.com';
EXEC spListarProveedor;
EXEC spGetProveedorRUC '20123456789';
EXEC spActualizarProveedor '20678901234', 'Proveedor Modificado', '084111111', 'mod@proveedor.com';
EXEC spEliminarProveedor '20678901234';